var data ={};
const readline = require('readline-sync');
const fs = require('fs');
let str;
fs.readFile('data.txt','UTF8',function(err,file){
  if (err){
    console.error(err);
  } else{
    file =  file.split('\n');
      for (var i=0; i<file.length; i++){
        str = file[i].split(';');
        if (str[0][1] == 'L') {
          str[0] = str[0].substring(3);
          data.imei = str[0];
          data.password = str[1];
        }
         else {
            str[0] = str[0].substring(3);
            data.date = str[0];
            data.time = str[1];
            data.lat = str[2]+';'+str[3];
            data.lon = str[4]+';'+str[5];
            data.course = str[7];
          };

      }
      let name = readline.prompt();
      console.log(data[name]);
  }
});
